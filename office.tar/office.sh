ssh -X test@192.168.122.240 libreoffice4.3
