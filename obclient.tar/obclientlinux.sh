mkdir /media/hey1
mount 192.168.122.240:/mnt/hey1 /media/hey1
