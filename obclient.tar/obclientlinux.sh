mkdir /media/adhoc
mount 192.168.122.240:/mnt/adhoc /media/adhoc
